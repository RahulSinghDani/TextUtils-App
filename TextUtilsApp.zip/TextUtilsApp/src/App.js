import './App.css';
import About from './Components/About';
import Alert from './Components/Alert';
import Navbar from './Components/Navbar';
import TextArea from './Components/TextArea';
import React, { useState } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from 'react-router-dom';

function App() {

  // ------------this is used for interval 
  setInterval(() => {
    document.title = "TextUtills is Amazing";
  }, 2000);
  setInterval(() => {
    document.title = "Install TextUtills";
  }, 1500);
  // ------------------------------------------

  const [mode, setMode] = useState('light');
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type) => {

    setAlert({
      msg: message,
      type: type
    })
    setTimeout(() => {
      setAlert(null);
    }, 1500);
  }


  const toggleMode = () => {
    if (mode === 'light') {
      setMode('dark');
      document.body.style.backgroundColor = "#313a48";
      document.body.style.color = "white";
      showAlert("Dark mode has been enabled", "success");
    }
    else if (mode === 'green') {
      showAlert("Please Disable Green Mode", "alert");
    }
    else {
      setMode('light');
      document.body.style.backgroundColor = "white";
      document.body.style.color = "black";
      showAlert("Light mode has been enabled", "success");
    }
  }
  const toggleMode1 = () => {
    if (mode === 'light') {
      setMode('green');
      document.body.style.backgroundColor = "#316236";
      document.body.style.color = "white";
      showAlert("Green Dark mode has been enabled", "success");
    }
    else if (mode === 'dark') {
      showAlert("Please Disable Dark Mode", "alert");
    }
    else {
      setMode('light');
      document.body.style.backgroundColor = "white";
      document.body.style.color = "black";
      showAlert("Light mode has been enabled", "success");
    }
  }

  return (
      <Router>
        {/* line number 11 in Navbar.js file   using props to interchange title from one file */}
        <Navbar title="TextUtils" mode={mode} toggleMode={toggleMode} toggleMode1={toggleMode1} />
        {/* <Navbar title={1} />    it will show error , because we apply props as a number . we defined title as a string in Navbar.js file in line 32 */}
        <Alert alert={alert} />
        <Routes>
          <Route path="/" element={<TextArea showAlert={showAlert} heading="Enter TEXT below" mode={mode} />}>
          </Route>

          <Route path="/about" element={<About mode={mode} />}>
          </Route>
        </Routes>
      </Router>
  );
}

export default App;
