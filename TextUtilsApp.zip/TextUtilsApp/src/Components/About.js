export default function About(props){

    return(
        <div className="container"  mode= {props.mode}>
            
            <h1>About Us</h1>
            <div className="aboutBox">
                <p>With the help of this website, we can modify the text or convert it according to our needs. In this we have facilities like copying, changing text to uppercase, lowercase, removing space, clearing the box, etc. This website will help in making work easier in everyday life.</p>
            </div>
        </div>
    )
}