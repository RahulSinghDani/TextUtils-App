import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
// import React, {useState} from 'react';
export default function Navbar(props) {
  // const [state , setState] = useState("Enable Dark Mode");

  return (
    <>
      <nav className={`navbar navbar-expand-lg navbar-${props.mode} bg-${props.mode}`}>
        <div className="container-fluid">
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
            <Link className="navbar-brand" to="/">{props.title}</Link>
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/about">About</Link>
              </li>
            </ul>
            <form className="d-flex" role="search">
              {/* <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
              <button className="btn btn-outline-success" type="submit">Search</button> */}
              {/* <button className="btn btn-primary" type="submit">Search</button> */}
              {/* this switch is used for dark and light mode  */}
              <div className={`form-check form-switch text-${props.mode === 'light' ? 'dark' : 'light'} mx-4` }>
                <input className="form-check-input" type="checkbox" onClick={props.toggleMode} role="switch" id="flexSwitchCheckDefault" />
                <label className="form-check-label" for="flexSwitchCheckDefault">{props.mode === 'light' ? "Enable DarkMode" : "Disable DarkMode"}</label>
                </div>

                {/* this switch is used for backgroundColor green */} 
                  <div className={`form-check form-switch text-${props.mode === 'light' ? 'green' : 'light'} && ${props.mode === 'dark' ? 'light' : 'green'} mx-4`}>
                  <input className="form-check-input" type="checkbox" onClick={props.toggleMode1} role="switch" id="flexSwitchCheckDefault1" />
                  <label className="form-check-label" for="flexSwitchCheckDefault">{props.mode === 'light' ? "Enable GreenMode" : "Disable GreenMode"}</label>
 
                </div>
            </form>
          </div>
        </div>
      </nav>
    </>
  )
}

// this propTypes check the given input is same type or not like title is string 
Navbar.propTypes = {
  title: PropTypes.string.isRequired
}


// this is default props , when you dont set a props it will work 
Navbar.defaultProps = {
  title: 'Title is not set yet(you have to go in app.js file in line number 9 inside Navbar'
}