import React ,{useState} from 'react';
export default function TextFile(props){
    const [text , setText] = useState("enter your text here... ");
    
    const clickButton= ()=>{

        setText("");
        console.log("text has been cleared successfully!");
    }
    const clearText= (event)=>{
        setText(event.target.value);

    }
    return(
        <>
            <div className="container">
                <h2>Enter text Below</h2>
                <textarea className="myBox" value={text} onChange={clearText} cols="80" rows="10"></textarea>
                <button className='btn btn-primary' onClick={clickButton}>Clear</button>
            </div>
           

        </>
    )
}
