import React, { useState } from 'react';

export default function TextArea(props) {

    const handleUpClick = () => {
        let newText = text.toUpperCase();
        setText(newText);
        if(text === ""){
            props.showAlert("Please Enter Some text Below to convert into uppercase","danger");
        }else{
        props.showAlert("Converted to Uppercse","success");
        }
    }
    const handleLcClick = () => {
        let newText = text.toLowerCase();
        setText(newText);
        if(text === ""){
            props.showAlert("Please Enter Some text Below to convert into lowecase","danger");
        }else{
            props.showAlert("Converted to Lowecase","success");
        }
        

    }
    const clearText= ()=>{

        setText("");
        // console.log("text has been cleared successfully!");

        props.showAlert("Text Cleared","success");

    }
    const copyText = ()=>{
        var txt = document.getElementById('myBox');
        txt.select();
        navigator.clipboard.writeText(txt.value);
        if(text === ""){
            props.showAlert("Text not availale for copy!","danger");
        }else{
            props.showAlert("Copied to clipboard","success");
        }



    }
    const handleSapces = ()=>{
        var newText = text.split(/[ ]+/);
        setText(newText.join(" "));
        if(text === ""){
            props.showAlert("Text not Available!","danger");
        }else{
            props.showAlert("Extra spaces removed ","success");
        }

    }

    const changeToUp = (event) => {
        // console.log("onChange function work");
        setText(event.target.value);
    }

    const [text, setText] = useState("");
    // let readTime =0;
    // if(text !== ""){
    //     readTime = 0.008 * text.split(" ").filter((element)=>{element.length !== 0}).length;
    // }
    
    return (

        <>
            <div className="container">
                <div className='mb-3'>
                    <h2 >{props.heading} </h2>
                    <textarea className='form-control ' style={{backgroundColor: props.mode === 'light'? 'white':'grey'}} id="myBox" value={text} onChange={changeToUp} cols="80" rows="6"></textarea>
                </div>
                <button disabled={text.length === 0} className='btn btn-primary mx-2 my-1' onClick={handleUpClick} >Convert to Uppercase</button>
                <button disabled={text.length === 0} className='btn btn-primary mx-2 my-1' onClick={handleLcClick}>Convert to LowerCase</button>
                <button disabled={text.length === 0} className='btn btn-primary mx-2 my-1' onClick={clearText}>Clear</button>
                <button disabled={text.length === 0} className="btn btn-primary mx-2 my-1" onClick={copyText}>Copy Text</button>
                <button disabled={text.length === 0} className="btn btn-primary mx-2 my-1" onClick={handleSapces}>Remove Spaces</button>
            </div>

            <div className="container">
                <h2 className='mb-1'>Text Summary </h2>
                <p>{text.split(/\s+/).filter((element) => {return element.length !==  0}).length} words and {text.length} characters</p>
                <p>{0.008 * text.split(" ").filter((element)=>{return element.length !== 0}).length} Minutes Read</p>
                <h2>Preview</h2>
                <p id='textpreview' style={{color:'black'}}>{text}</p>
            </div>
        </>
    )
}
